plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.hesab.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.hesab.app"; minSdk = 26; targetSdk = 34; versionCode = 5; versionName = "0.5" }
    signingConfigs {
        create("fixed") {
            storeFile = file("hesab.p12"); storeType = "pkcs12"
            storePassword = "hesab123"; keyAlias = "hesab"; keyPassword = "hesab123"
        }
    }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("fixed") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
}
