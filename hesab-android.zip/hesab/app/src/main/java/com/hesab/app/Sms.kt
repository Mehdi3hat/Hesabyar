package com.hesab.app
import android.content.Context
import android.provider.Telephony
import org.json.JSONObject

fun en(s: String): String {
    val sb = StringBuilder()
    for (ch in s) sb.append(when (ch) {
        in '۰'..'۹' -> '0' + (ch - '۰')
        in '٠'..'٩' -> '0' + (ch - '٠')
        else -> ch
    })
    return sb.toString()
}

object SmsParse {
    class Hit(val rial: Long, val out: Boolean, val key: String)

    fun check(c: Context, sender: String, body: String): Hit? {
        val t = en(body).replace('ي', 'ی').replace('ك', 'ک').trim()
        val first = t.lineSequence().firstOrNull()?.trim() ?: ""
        val pres = (Store.p(c).getString("pre", "3003,B.QMEHRIRAN,700717") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (pres.none { first.startsWith(it) || sender.startsWith(it, true) }) return null
        if (t.contains("رمز")) return null
        val u = t.replace(Regex("\\d{4}/\\d{1,2}/\\d{1,2}\\s*-\\s*\\d{1,2}:\\d{2}"), " ")
            .replace(Regex("(?<!\\d)\\d{4}\\s*-\\s*\\d{1,2}:\\d{2}"), " ")
            .replace(Regex("(حساب|مانده)\\s*:?\\s*[\\d,]+"), " ")
        val m2 = Regex("([-+])\\s*([\\d,]{3,})").find(u)
        val m1 = Regex("([\\d,]{3,})\\s*([-+])").find(u)
        val (amt, sign) = when {
            m2 != null -> m2.groupValues[2] to m2.groupValues[1]
            m1 != null -> m1.groupValues[1] to m1.groupValues[2]
            else -> return null
        }
        val rial = amt.replace(",", "").toLongOrNull() ?: return null
        val key = Regex("حساب\\s*:?\\s*(\\d+)").find(t)?.groupValues?.get(1) ?: if (Regex("^\\d{6,}$").matches(first)) first else sender
        return Hit(rial, sign == "-", key)
    }
}

object SmsImport {
    fun run(c: Context): Int {
        val since = System.currentTimeMillis() - 90L * 86400000L
        val list = ArrayList<JSONObject>()
        try {
            c.contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf("_id", "address", "body", "date"),
                "date>?", arrayOf(since.toString()), "date ASC")?.use { cur ->
                while (cur.moveToNext()) {
                    val addr = cur.getString(1) ?: ""; val body = cur.getString(2) ?: ""
                    if (SmsParse.check(c, addr, body) != null)
                        list.add(JSONObject().put("id", "sms" + cur.getLong(0)).put("raw", body).put("sender", addr).put("ts", cur.getLong(3)).put("imp", true))
                }
            }
        } catch (e: Exception) { return 0 }
        Store.addAll(c, list)
        return list.size
    }
}
