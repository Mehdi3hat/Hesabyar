package com.hesab.app
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput

class NoteReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val cat = i.getStringExtra("cat")
        val note = RemoteInput.getResultsFromIntent(i)?.getCharSequence("note")?.toString()
        Store.update(c, id, cat, note)
        c.getSystemService(NotificationManager::class.java).cancel(i.getIntExtra("nid", 0))
    }
}
