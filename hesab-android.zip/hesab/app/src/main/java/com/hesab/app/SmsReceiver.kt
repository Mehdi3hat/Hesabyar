package com.hesab.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONObject

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val ms = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val body = ms.joinToString("") { it.messageBody ?: "" }
        val sender = ms.firstOrNull()?.originatingAddress ?: ""
        val hit = SmsParse.check(c, sender, body) ?: return
        val id = System.currentTimeMillis().toString() + "_" + (0..999).random()
        Store.add(c, JSONObject().put("id", id).put("raw", body).put("sender", sender).put("ts", System.currentTimeMillis()))
        Notify.tx(c, id, hit.rial, hit.out, hit.key)
    }
}
