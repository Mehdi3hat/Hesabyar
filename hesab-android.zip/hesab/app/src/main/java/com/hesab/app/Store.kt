package com.hesab.app
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    fun p(c: Context) = c.getSharedPreferences("d", 0)

    @Synchronized fun add(c: Context, o: JSONObject) {
        val a = JSONArray(p(c).getString("inbox", "[]"))
        a.put(o); p(c).edit().putString("inbox", a.toString()).apply()
    }
    @Synchronized fun addAll(c: Context, os: List<JSONObject>) {
        val a = JSONArray(p(c).getString("inbox", "[]"))
        os.forEach { a.put(it) }
        p(c).edit().putString("inbox", a.toString()).apply()
    }
    @Synchronized fun update(c: Context, id: String, cat: String?, note: String?) {
        val a = JSONArray(p(c).getString("inbox", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("id") == id) { cat?.let { o.put("cat", it) }; note?.let { o.put("note", it) } }
        }
        p(c).edit().putString("inbox", a.toString()).apply()
    }
    @Synchronized fun take(c: Context): String {
        val s = p(c).getString("inbox", "[]") ?: "[]"
        p(c).edit().putString("inbox", "[]").apply(); return s
    }
    fun accName(c: Context, key: String): String = try { JSONObject(p(c).getString("accs", "{}") ?: "{}").optString(key, "") } catch (e: Exception) { "" }
    fun cats(c: Context, out: Boolean): List<String> {
        val d = if (out) listOf("خوراک", "حمل‌ونقل", "خرید") else listOf("حقوق", "هدیه", "سایر")
        return try {
            val a = JSONObject(p(c).getString("cats", "{}") ?: "{}").optJSONArray(if (out) "out" else "in") ?: return d
            List(a.length()) { a.getString(it) }
        } catch (e: Exception) { d }
    }
}
