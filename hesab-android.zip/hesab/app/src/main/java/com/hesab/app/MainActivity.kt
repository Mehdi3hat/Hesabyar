package com.hesab.app
import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var w: WebView
    private var pending = ""

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        w = WebView(this); setContentView(w)
        // blue while the splash animation plays; applyBars() switches to the app colors afterwards
        w.setBackgroundColor(Color.parseColor("#1B2F8F"))
        window.statusBarColor = Color.parseColor("#2F6BFF")
        window.navigationBarColor = Color.parseColor("#0F1B3D")
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("file:///android_asset/index.html")
        Reminder.schedule(this)
        if (hasPerms()) scan()
    }

    private fun applyBars() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val bg = if (night) Color.parseColor("#0A1022") else Color.parseColor("#F1F4FB")
        w.setBackgroundColor(bg); window.statusBarColor = bg; window.navigationBarColor = bg
        window.decorView.systemUiVisibility = if (night) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
    }

    private fun hasPerms() =
        checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED &&
        checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    private fun scan() {
        thread {
            if (!Store.p(this).getBoolean("imported", false)) {
                SmsImport.run(this)
                Store.p(this).edit().putBoolean("imported", true).apply()
            }
            runOnUiThread { w.evaluateJavascript("window.onNative&&window.onNative()", null) }
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (hasPerms()) scan()
    }

    override fun onResume() {
        super.onResume()
        if (::w.isInitialized) w.evaluateJavascript("window.onNative&&window.onNative()", null)
    }

    @Deprecated("old api")
    override fun onBackPressed() {
        w.evaluateJavascript("window.onBackJs?window.onBackJs():false") { r -> if (r != "true") finish() }
    }

    @Deprecated("old api")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == 11) {
            contentResolver.openOutputStream(uri)?.use { it.write(pending.toByteArray()) }
            pending = ""
            w.evaluateJavascript("window.onBackupDone&&window.onBackupDone()", null)
        } else if (req == 12) {
            val t = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return
            w.evaluateJavascript("window.onRestore&&window.onRestore(" + JSONObject.quote(t) + ")", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface fun inbox(): String {
            getSystemService(NotificationManager::class.java).cancelAll()
            return Store.take(this@MainActivity)
        }
        @JavascriptInterface fun setCats(j: String) { Store.p(this@MainActivity).edit().putString("cats", j).apply() }
        @JavascriptInterface fun setAccs(j: String) { Store.p(this@MainActivity).edit().putString("accs", j).apply() }
        @JavascriptInterface fun setPrefixes(s: String) { Store.p(this@MainActivity).edit().putString("pre", s).apply() }
        @JavascriptInterface fun setReminder(h: Int, m: Int) {
            val sp = Store.p(this@MainActivity)
            if (sp.getInt("rh", -1) != h || sp.getInt("rm", -1) != m) {
                sp.edit().putInt("rh", h).putInt("rm", m).apply(); Reminder.schedule(this@MainActivity)
            }
        }
        @JavascriptInterface fun setUnit(u: String) { Store.p(this@MainActivity).edit().putString("unit", u).apply() }
        @JavascriptInterface fun openSettings() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
            }
        }
        @JavascriptInterface fun splashDone() { runOnUiThread { applyBars() } }
        @JavascriptInterface fun hasPerms(): Boolean = this@MainActivity.hasPerms()
        @JavascriptInterface fun requestPerms() {
            runOnUiThread {
                val p = mutableListOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
                if (Build.VERSION.SDK_INT >= 33) p.add("android.permission.POST_NOTIFICATIONS")
                requestPermissions(p.toTypedArray(), 1)
            }
        }
        @JavascriptInterface fun rescan() {
            Store.p(this@MainActivity).edit().putBoolean("imported", false).apply(); scan()
        }
        @JavascriptInterface fun exportBackup(j: String) {
            pending = j
            runOnUiThread {
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json").putExtra(Intent.EXTRA_TITLE, "hesab-backup.json"), 11)
            }
        }
        @JavascriptInterface fun importBackup() {
            runOnUiThread {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 12)
            }
        }
        @JavascriptInterface fun canBio(): Boolean {
            if (Build.VERSION.SDK_INT < 30) return false
            val m = getSystemService(BiometricManager::class.java) ?: return false
            return m.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
        }
        @JavascriptInterface fun biometric() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT < 28) return@runOnUiThread
                val ex = this@MainActivity.mainExecutor
                val bp = BiometricPrompt.Builder(this@MainActivity).setTitle("حسابدار")
                    .setNegativeButton("استفاده از رمز", ex) { _, _ -> }.build()
                bp.authenticate(CancellationSignal(), ex, object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) {
                        w.evaluateJavascript("window.onBio&&window.onBio()", null)
                    }
                })
            }
        }
    }
}
